Witnesses for the 8-element matroid quadratic triangulation campaign
====================================================================
This document was AI generated and summarizes work of Spencer Backman, Nathan Cheung, Michal Lason, Gaku Liu, and  Mateusz Michalek.

This archive contains witnesses certifying that the base polytope of each
listed matroid admits a quadratic triangulation.  All witnesses were produced
by the pipeline_4_19 pipeline and verified by two independent checks (see
Verification below).

Summary
-------
  Rank-3 candidates:  43 / 43 verified
  Rank-4 candidates: 434 / 435 verified
  Total:             477 / 478 verified
  Open:              r4e8_c121 (T8)

Mathematical context
--------------------
A quadratic triangulation of a matroid base polytope P is a triangulation that
is simultaneously:
  - regular   (induced by a height function h on the vertices of P)
  - unimodular (every maximal simplex has normalized volume 1)
  - flag       (the triangulation equals the clique complex of its 1-skeleton)

The equivalence of these conditions with the existence of a quadratic squarefree
Groebner basis for the toric ideal of the matroid is due to work of Sturmfels,
White, and others; 

What a witness is
-----------------
A witness is a pair (E, h) where:

  E  is a set of chosen pairs of basis vertices (selected_edges file)
  h  is a height function on the basis vertices (heights file)

satisfying three conditions:
  (1) every midpoint-equivalence class of vertex pairs contains at least
      one pair from E
  (2) in each equivalence class, the pair in E strictly minimizes h_i + h_j
  (3) for every circuit (C+, C-) of the matroid, not both C+ and C- are
      cliques in E

Any (E, h) satisfying (1)-(3) certifies the existence
of a flag, regular, unimodular triangulation.  The heights file records the SAT
solver's output; the selected_edges file records E.

File format
-----------
Heights file (<matroid>_heights.txt):
  One line per basis vertex:
    <index>  <vertex_coordinates_as_01_vector>  <height_value>
  Example:
    0  (1, 1, 0, 0, 0, 1, 0, 0)  (- 236.0)
    1  (1, 1, 0, 0, 0, 0, 1, 0)  (- 291.0)
    ...

Selected edges file (<matroid>_selected_edges.txt):
  One line per chosen pair:
    (<i>, <j>)
  where i and j are indices into the heights file (zero-based).

Matroid indexing
----------------
Matroids are identified by their position in Sage's enumeration of 8-element
matroids by isomorphism class.  The ordering within each rank was fixed at the
start of the campaign.

  r3e8_c001 through r3e8_c043  -- the 43 rank-3 candidates
  r4e8_c001 through r4e8_c435  -- the 435 rank-4 candidates
    (r4e8_c121 = T8 is excluded; no witness found yet)

Witness label
-------------
Each witness carries a label of the form iter<N>_incl<P>_n<C>, appearing in
the filename of the source run.  The components are:

  iter<N>  -- pipeline iteration in which SAT was found
  incl<P>  -- percentage of estimated total restricted circuits in the tranche
  n<C>     -- number of restricted circuits included in the tranche

Note: the tranche size n<C> is the total circuits available to cvc5 at that
iteration, not the number cvc5 consumed before finding SAT (which is
generally smaller).

Verification
------------
Each witness was verified by two independent checks:

  1. Quadratic Triangulation Verifier (QTV): checks that the clique complex on
     E is a valid triangulation, that all maximal simplices are unimodular
     (determinant +/-1), and that the triangulation is regular (certified by a
     linear program using the heights h).  This is a direct mathematical
     certificate.

  2. Full-circuit audit: independently confirms that condition (3) holds for
     every circuit of the ambient Delta polytope restricted to the matroid --
     not only the circuits used during the SAT search.  This is a correctness
     check on the encoding rather than a mathematical requirement (QTV alone is
     sufficient), but it provides an independent confirmation of the result.

Runtime and memory
------------------
See manifest.csv for per-matroid elapsed wall time and peak RAM (MaxRSS from
Slurm accounting).

Summary across all 477 verified matroids:

  Rank-3 (43 matroids):
    Elapsed:  min 0.2 min,  median 0.7 min,  max 156 min  (r3e8_c013)
    Peak RAM: min 11 MB,    median 146 MB,    max 1.1 GB   (r3e8_c013)

  Rank-4 (434 matroids, excluding T8):
    Elapsed:  min 0.2 min,  median 8.9 min,  max 1789 min (r4e8_c151)
    Peak RAM: min 1 MB,     median 489 MB,   max 2.4 GB   (r4e8_c151)

Three matroids required significantly more resources than the rest and are
documented in detail in hard_cases_8elt_matroids.txt:

  r3e8_c013  (AG(2,3)^-)           2h 36m    525 MB
  r4e8_c051  (AG(2,3)^- Delta-Y)  19h 31m    1.8 GB
  r4e8_c151  (unnamed, near T8)   29h 49m    2.4 GB

Open case
---------
r4e8_c121 = T8 (the named rank-4 matroid on 8 elements with 59 bases and
nonbases {0123, 0145, 0167, 0246, 0257, 0347, 1247, 1256, 1346, 2345, 3567})
is not included in this archive.  Investigation is ongoing.
